# ABBE MISTRAL

Detta repo innehåller en enkel statisk webbsida. Öppna `index.html` i webbläsaren.

Ladda också upp `logo.png` i samma mapp om du vill visa logotypen.
